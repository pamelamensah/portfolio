# 🍎 macOS Security Guide for Masquerader Game

## 🔒 Understanding the Security Warning

When you try to run `Play_Masquerader_Mac.command`, you'll see this message:
> "Apple could not verify 'Play_Masquerader_Mac.command' is free of malware that may harm your Mac or compromise your privacy."

**This is completely normal and safe!** It's Apple's Gatekeeper security system protecting your Mac.

## ✅ Quick Solutions (Choose One)

### **Method 1: Right-Click and Open (Easiest)**
1. **Right-click** on `Play_Masquerader_Mac.command`
2. Select **"Open"** from the menu
3. Click **"Open"** in the warning dialog
4. The game will start normally!

### **Method 2: System Preferences (One-time setup)**
1. Go to **System Preferences** → **Security & Privacy**
2. Click the **"General"** tab
3. Look for the message about `Play_Masquerader_Mac.command`
4. Click **"Allow Anyway"**
5. Now you can double-click normally

### **Method 3: Terminal Command (Alternative)**
1. Open **Terminal** (Applications → Utilities → Terminal)
2. Navigate to the game folder: `cd /path/to/Masquerader_Mac_Package`
3. Run: `./Play_Masquerader_Mac.command`

### **Method 4: Remove Quarantine Attribute**
1. Open **Terminal**
2. Navigate to the game folder
3. Run: `xattr -rd com.apple.quarantine Play_Masquerader_Mac.command`
4. Now you can double-click normally

## 🎯 Why This Happens

- **Gatekeeper** blocks unsigned applications by default
- **Your game is safe** - it's just not digitally signed by Apple
- **This is common** for indie games and personal projects
- **Once allowed**, macOS remembers your choice

## 🚀 Alternative: Use the JAR File Directly

If you prefer, you can also run the game directly:

1. Open **Terminal**
2. Navigate to the game folder
3. Run: `java -jar MasqueraderGame_Java8.jar`

## 🔧 Troubleshooting

**Still getting warnings:**
- Try Method 2 (System Preferences)
- Restart your Mac and try again
- Check if you have any security software blocking it

**Game won't start:**
- Ensure Java is installed: `java -version` in Terminal
- Download Java from: https://www.java.com/download/

**No sound:**
- Check system volume
- Ensure `background.wav` is in the same folder

## 📞 Need Help?

The game is completely safe to run. This is just macOS being protective. Once you open it once, you won't see the warning again!

---

**Enjoy solving the mystery of the Masquerader!** 🕵️‍♀️🎭 